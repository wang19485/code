My name: Yingjian Wang
UIN: 726004401

Two colors for mode 2: Top-> cyan(0,255,255); Bottom-> yellow(255,255,0);

All code is written by myself, no citation.

The following three images are created by default: 

Drawing bounding box
Drawing Triangles
Z-buffering tests

Mode 0, 1 and 2 are followed the instruction.

Tips:
In the main.cpp, I think the mode we need to accomplish is not complex. Thus, I think  there is no need to create functions outside main(). So, I write everything in main() and comment clearly to explain the codes. And I think the running time is pretty good without any unnecessary functions.