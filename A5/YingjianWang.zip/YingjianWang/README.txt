Name:  Yingjian Wang

I finished scene1, scene2, scene3 and scene4. 

**** Please use the following command pattern to run the program ****
./A5 1 1024 1024 output.png ../resources/bunny.obj

Important Note about running time:
I run my code in Xcode, which takes two or three seconds to finish scene 1,2 and 3. For scene 4, it takes 15 seconds for bunny.obj in 1024*1024 image. However, when I run my code in Mac's terminal, it takes much much longer time. For example, it takes minutes to run scene 3, and like 10 second to run scene 1 or 2, which makes me very confused.

So, I highly recommend to run the code in Xcode with release mode. Thank you!