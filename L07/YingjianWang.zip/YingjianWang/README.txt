Name:  Yingjian Wang

There might be some line of code similar to the resources below:
https://learnopengl.com/Getting-started/Camera

The program works well and do exactly same as requirement.

**** Please use the following command to run the program ****
./A4 ../resources ../resources/bunny.obj ../resources/teapot.obj ../resources/cube.obj ../resources/sphere.obj

(The order of the obj files matters!)