import java.io.BufferedReader;
import java.io.FileReader;

// Write code to load the workouts from the provided workouts.csv file. The function should return a Workouts object.

public class FileAccess {
	
  public static Workouts loadWorkouts() throws Exception{
    
	  // What is a try/catch block and why do we need one?
      // What is an exception?
	  
	  Workouts workouts = new Workouts();
	  String string = null;
	  try {
		  BufferedReader reader = new BufferedReader(new FileReader(Config.WORKOUTFILE));
		  while ((string = reader.readLine()) != null) {
			  String[] line = string.split(",");
			  workouts.addWorkout(line[0], Workouts.Equipment.valueOf(line[1]), Workouts.Muscle.valueOf(line[2]), Workouts.Muscle.valueOf(line[3]), line[4], line[5]);
		  }	
		  reader.close();
	} catch (Exception e) {
		// TODO: handle exception
		System.out.println("File does Not Exist.");
	}
	return workouts; 
  }

}
