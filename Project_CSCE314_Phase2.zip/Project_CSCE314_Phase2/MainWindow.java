import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.EnumMap;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

// Bonus points: Create an icon (or find a public domain icon. Keep in mind federal Copyright law and TAMU's plagiarism policy and add it to the home screen window.
public class MainWindow {
  
  private final JFrame mainFrame = new JFrame(Config.APPLICATIONNAME);
  private final JDialog selectWorkout = new JDialog(mainFrame, "Select Workout");
  private JComboBox<String> cboType, cboGoal;
  private JSpinner spnDuration;
  private final Workouts workouts;
  private final EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> muscleGroups;

  MainWindow(Workouts workouts, EnumMap<Config.MuscleGroup, ArrayList<Config.Muscle>> muscleGroups) {
    this.workouts = workouts;
    this.muscleGroups = muscleGroups;
    launchHomeScreen();
  }
  
  private void launchHomeScreen() {
	  JButton btn1 = new JButton("Upper Body Workout");
	    JButton btn2 = new JButton("Lower Body Workout");
	    JButton btn3 = new JButton("Whole Body Workout");
	    //mainFrame.setIconImage(new ImageIcon(getClass().getResource("icons8-java-50.png")).getImage()); **don't know why not working
	    mainFrame.setLayout(null);
	    btn1.setBounds(0, 0, 600, 130);
	    btn2.setBounds(0,125,600,130);
	    btn3.setBounds(0,250,600,130);
	    mainFrame.add(btn1);
	    mainFrame.add(btn2);
	    mainFrame.add(btn3);
	    mainFrame.setSize(new Dimension(600, 400));
	    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    mainFrame.setVisible(true);
	    btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showWorkouts(muscleGroups.get(Config.MuscleGroup.UPPERBODY));
			}
		});
	    btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showWorkouts(muscleGroups.get(Config.MuscleGroup.LOWERBODY));
			}
		});
	    btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showWorkouts(muscleGroups.get(Config.MuscleGroup.WHOLEBODY));
			}
		});
	    
	    
  }
  
  // This is the method your actionlistener should call. It should create and display a WorkoutsPanel.
  private void showWorkouts(ArrayList<Config.Muscle> muscles) {
	  JFrame frame2 = new JFrame(Config.APPLICATIONNAME);
	  frame2.setVisible(true);
	  frame2.setSize(new Dimension(600,400));
      frame2.add(new WorkoutsPanel(muscles, this.workouts));
  }
}
